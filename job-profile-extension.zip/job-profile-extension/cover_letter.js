document.getElementById('generate').addEventListener('click', runAI)
    
async function runAI() {
    if(activeProfile==null){
        return alert('Select a profile for generating cover letter')
    }
    console.log(activeProfile)

    const genAI = new window.GoogleGenerativeAI(
        "AIzaSyD3V-F_kvKhOkDdgHX7w5OCS-oiMQJhCJs"
    );
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = "print 5+5";

    console.log(prompt)

    let retries = 3; // Number of retries
    let delay = 5000; // Delay between retries in milliseconds
    let aiOutput = ""; // Variable to store the AI response

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            console.log(`Attempt ${attempt}...`);
            const result = await model.generateContent(prompt);

            // Extract the text from the AI response
            aiOutput = result.response.text();

            console.log("Generated Response:", aiOutput);

            // Write the AI output to the textarea with id "coverLetter"
            const coverLetterTextarea = document.getElementById("cover_letter");
            if (coverLetterTextarea) {
                coverLetterTextarea.value = aiOutput; // Write response to textarea
            } else {
                console.error("Textarea with id 'coverLetter' not found.");
            }
            return; // Exit after a successful response
        } catch (error) {
            if (attempt < retries) {
                console.error(
                    `Error during API call (Attempt ${attempt}):`,
                    error.message
                );
                console.log(`Retrying in ${delay / 1000} seconds...`);
                await new Promise((res) => setTimeout(res, delay));
            } else {
                console.error("All retry attempts failed. Please try again later.");
                return;
            }
        }
    }
}